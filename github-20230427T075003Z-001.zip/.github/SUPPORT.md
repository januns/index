### Bug reports

See the [contributing guidelines](CONTRIBUTING.md) for sharing bug reports.

### How-to

For general troubleshooting or help getting started:

- Join [the official community](https://community.coreui.io/).
- Ask and explore Stack Overflow with the [`coreui`](https://stackoverflow.com/questions/tagged/coreui) tag.
